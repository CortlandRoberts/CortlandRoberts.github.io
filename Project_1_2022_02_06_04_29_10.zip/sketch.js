let r;
let g;
let b;
let x;
let y;
function setup() {
  createCanvas(windowWidth, windowHeight);
  stroke('ivory');
}

function draw() {
  
  //Draws the D
  line(30, 250, 85, 250);
  stroke(126);
  line(85, 300, 85, 250);
  stroke(255);
  line(85, 300, 30, 300);
  
  
  //This Draws A
  stroke(126);
  line(250, 300, 170, 250);
  stroke(255);
  line(100, 300, 170, 250);
  
  
  //This draws the T 
  line(250, 250, 370, 250);
  stroke(126);
  line(320, 250, 320, 300);
  
  
  
  
  //This Draws the A
  stroke(126);
  line(400, 300, 500, 250);
  stroke(255);
  line(600, 300, 500, 250);
  
  
  //Here i am creating a random function that makes dots accross the screen
  
  r = random(255);
  g = 0;
  b = random(255);
  x = random(width);
  y = random(height);
  noStroke();
  fill(r, g, b, 50);
  circle(x, y, 10);

}